#include "StdAfx.h"
#include "ABMarchivo.h"
#include "Archivo.h"

class ABMarchivo
{
private:
	string nombreArchivo;
	Archivo *archi;

public:
	ABMarchivo(string nomAr){
		nombreArchivo=nomAr;
	}
	void adicionarNuevo(Archivo ar)
	{
		ofstream fsalida(nombreArchivo, ios::app | ios::binary);	

			//A1.Set_Archivo(archi);
			ar.guardarArchivo(fsalida);	
			fsalida.close();
	}
	void listar()
	{
		archi=new Archivo();
		ifstream fentrada(nombreArchivo, ios::in | ios::binary);
	}
};


