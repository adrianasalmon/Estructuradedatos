#include "StdAfx.h"
#include "Vector.h"
#define MAX 10
#include <iostream>
using namespace std;

Vector::Vector(void)
{
	V[MAX]=0;
	tamano=0;
}
int Vector::Get_Vector(int posicion)
{
	return V[posicion];
}
void Vector::Set_Vector(int elemento,int posicion)
{
	V[posicion]=elemento;
}
int Vector::Get_Tamano()
{
	return tamano;
}
void Vector::Set_Tamano(int tam)
{
	tamano=tam;
}
bool Vector::Lleno_Vector()
{
	if(tamano==(MAX-1))
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Vector::Vacio_Vector()
{
	if(tamano==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool Vector::Ingresar_Vector(int elemento,int posicion)
{
	if((posicion<0)||(posicion>tamano))
	{
		return false;
	}
	else
	{
		if(Lleno_Vector()==true)
		{
			return false;
		}
		else
		{
			int i=Get_Tamano();
			if(i>posicion)
			{
				V[i]=V[i-1];
				i--;
			}
			V[posicion]=elemento;
			return true;
		}
	}
}
int Vector::Pares_vector()
{
	int cp=0; 
	for(int i=0;i<Get_Tamano();i++)
	{
		if(V[i]%2==0)
		{
			cp++;
		}
	}
	return cp;
}
int Vector::Impares_vector()
{
	int ci=0; 
	for(int i=0;i<Get_Tamano();i++)
	{
		if(V[i]%2!=0)
		{
			ci++;
		}
	}
	return ci;
}