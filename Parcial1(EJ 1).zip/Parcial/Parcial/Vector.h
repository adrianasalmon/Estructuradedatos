#pragma once
#define MAX 10
class Vector
{
private:
	int V[MAX];
	int tamano;
public:
	Vector(void);
	int Get_Vector(int posicion);
	void Set_Vector(int elemento,int posicion);
	int Get_Tamano();
	void Set_Tamano(int tam);
	bool Lleno_Vector();
	bool Vacio_Vector();
	bool Ingresar_Vector(int elemento,int posicion);
	int Pares_vector();
	int Impares_vector();

};
