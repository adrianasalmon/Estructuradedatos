#include "StdAfx.h"
#include "Mat.h"

Mat::Mat(void)
{ col=0;
 fil=0;
 Matriz[a][b]=0;
}
int Mat::Get_fil()
{ return fil;
}
void Mat::Set_fil(int f)
    { fil=f;
	}
int Mat::Get_col()
	{ return col;
	}
void Mat::Set_col(int c)
	{ col=c;
	}
int Mat::Get_Matriz(int posf, int posc)
	{ return Matriz[posf][posc];
	}
void Mat::Set_Matriz(int posf, int posc, int ele)
	{ Matriz[posf][posc]=ele;
	}

bool Mat::LLena()
{
	if (fil==a-1 && col==b-1)
	{
		return true;
	}
	else
	{
		return false;
	}

}
bool Mat::Vacia()
{
	if(fil==0 && col==0)
		{
	return true;
}
else
	{
		return false;
	}

}

Mat Mat::Suma(Mat M1, Mat M2)
{
	Mat M3;
	M3.Set_fil(M1.Get_fil());
	M3.Set_col(M1.Get_col());
	for(int f=0;f<M3.Get_fil();f++)
	{
		for(int c=0;c<M3.Get_col();c++)
		{
			M3.Set_Matriz(f,c,M1.Get_Matriz(f,c)+M2.Get_Matriz(f,c));
		}
	}
	return M3;
}