

#include "stdafx.h"
#include <iostream>
#include "conio.h"
#include "Vector.h"
using namespace std;


void main()
{
	int vec1[50];
	int vec2[50];
	int vec3[100];
	int n1;
	int n2;
	int n3;
	cout<<"Ingrese el tama�o del vector 1";
	cout<<endl;
	cin>>n1;
	cout<<"Ingrese el tama�o del vector 2";
	cout<<endl;
	cin>>n2;
	n3=n1+n2;
	Vector vector1;
	vector1.cargarvector(vec1,n1);
	vector1.mostrarvector(vec1,n1);
	vector1.cargarvector(vec2,n2);
	vector1.mostrarvector(vec2,n2);
	vector1.concatenarvector(vec3,vec1,n1,vec2,n2);
	cout<<"Vector concatenado";
	cout<<endl;
	vector1.mostrarvector(vec3,n3);
}

