#pragma once
class Vector
{
private:
	int vec1[50];
	int vec2[50];
	int vec3[100];
	int n1;
	int n2;
	int n3;
public:
	Vector(void);
	~Vector(void);
	void cargarvector(int vec[],int n);
	void mostrarvector(int vec[], int n);
	void concatenarvector(int vec3[], int vec1[],int n1,int vec2[], int n2);
};

