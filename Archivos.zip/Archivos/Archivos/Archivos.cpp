// Archivos.cpp : main project file.

#include "stdafx.h"

#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include "ABMamigo.cpp"

using namespace std;


void main() {
	int opc=0;
		
	 do{ 
        cout<<"1. Adicionar Nuevo"<<endl; 
        cout<<"2. listar"<<endl; 
        cout<<"3. buscar reg"<<endl; 
        cout<<"4. eliminar reg"<<endl; 
		cout<<"5. modificar registro"<<endl;
		cout<<"6. listar"<<endl;
        cout<<"Opcion: "; cin>>opc; 
         ABMamigo *amig = new ABMamigo("amigOO.dat");
         
        switch (opc){ 
        case 1 : 
			amig->adicionarNuevo();
			break;
        case 2 : 
            amig->listar();
            break; 
        case 3: 
            amig->buscarReg();
            break ; 
	    case 4: 
            amig->eliminarReg();
            break ;        
		case 5: 
            amig->modificarReg();
            break ;        
		case 6: 
            amig->listar();
            break ;
             
        } 
        cout<<"ingresar una opcion";
		cin>>opc;
    }while(opc != 6); 
	 getch();
}

