#include "StdAfx.h"
#include "Pila.h"


Pila::Pila(void)
{
	tope=-1;
	pila[N]=0;
}
int Pila::Get_tope()
{
	return tope;
}
void Pila::Set_tope(int t)
{
	tope=t;
}
bool Pila::Pila_vacia()
{
	if(tope==0) 
	{ 
		return true;
	}
	else 
	{
		return false;
	}
}
bool Pila::Pila_llena()
{
	if(tope==N-1) 
	{ 
		return true;
	}
	else 
	{
		return false;
	}
}
void Pila::Apilar(int a)
{
		tope++;
		pila[tope]=a;
}
int Pila::Desapilar()
{
		return pila[tope--]; 
}
