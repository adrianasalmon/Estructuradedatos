#pragma once
#define N 30
class Pila
{
	int pila[N];
	int tope;
public:
	Pila(void);
	int Get_tope();
	void Set_tope(int t);
	bool Pila_vacia();
	bool Pila_llena();
	void Apilar(int a);
	int Desapilar();

};

