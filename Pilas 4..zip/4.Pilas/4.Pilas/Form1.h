#pragma once
#include "Pila.h"

namespace My4Pilas {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	Pila P1;
	Pila P2;
	int pos=0;
	int pos2=0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtApilar;
	private: System::Windows::Forms::Button^  btnApilar;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Pila;
	private: System::Windows::Forms::TextBox^  txtPosicion;


	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  btnInsertarNuevoElemento;

	private: System::Windows::Forms::TextBox^  txtElemento;

	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::DataGridView^  Grid2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtApilar = (gcnew System::Windows::Forms::TextBox());
			this->btnApilar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Pila = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtPosicion = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->btnInsertarNuevoElemento = (gcnew System::Windows::Forms::Button());
			this->txtElemento = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->dataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(24, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(37, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"PILA";
			// 
			// txtApilar
			// 
			this->txtApilar->Location = System::Drawing::Point(18, 82);
			this->txtApilar->Name = L"txtApilar";
			this->txtApilar->Size = System::Drawing::Size(146, 22);
			this->txtApilar->TabIndex = 1;
			// 
			// btnApilar
			// 
			this->btnApilar->Location = System::Drawing::Point(194, 75);
			this->btnApilar->Name = L"btnApilar";
			this->btnApilar->Size = System::Drawing::Size(143, 36);
			this->btnApilar->TabIndex = 2;
			this->btnApilar->Text = L"Apilar";
			this->btnApilar->UseVisualStyleBackColor = true;
			this->btnApilar->Click += gcnew System::EventHandler(this, &Form1::btnApilar_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Pila});
			this->Grid->Location = System::Drawing::Point(21, 156);
			this->Grid->Name = L"Grid";
			this->Grid->RowTemplate->Height = 24;
			this->Grid->Size = System::Drawing::Size(253, 312);
			this->Grid->TabIndex = 3;
			this->Grid->RowCount = 30;
			// 
			// Pila
			// 
			this->Pila->HeaderText = L"Pila";
			this->Pila->Name = L"Pila";
			// 
			// txtPosicion
			// 
			this->txtPosicion->Location = System::Drawing::Point(97, 521);
			this->txtPosicion->Name = L"txtPosicion";
			this->txtPosicion->Size = System::Drawing::Size(146, 22);
			this->txtPosicion->TabIndex = 5;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(24, 524);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(60, 17);
			this->label2->TabIndex = 4;
			this->label2->Text = L"posicion";
			// 
			// btnInsertarNuevoElemento
			// 
			this->btnInsertarNuevoElemento->Location = System::Drawing::Point(260, 524);
			this->btnInsertarNuevoElemento->Name = L"btnInsertarNuevoElemento";
			this->btnInsertarNuevoElemento->Size = System::Drawing::Size(143, 36);
			this->btnInsertarNuevoElemento->TabIndex = 9;
			this->btnInsertarNuevoElemento->Text = L"Insertar elemento";
			this->btnInsertarNuevoElemento->UseVisualStyleBackColor = true;
			this->btnInsertarNuevoElemento->Click += gcnew System::EventHandler(this, &Form1::btnInsertarNuevoElemento_Click);
			// 
			// txtElemento
			// 
			this->txtElemento->Location = System::Drawing::Point(97, 579);
			this->txtElemento->Name = L"txtElemento";
			this->txtElemento->Size = System::Drawing::Size(146, 22);
			this->txtElemento->TabIndex = 8;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(24, 582);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(66, 17);
			this->label3->TabIndex = 7;
			this->label3->Text = L"elemento";
			// 
			// Grid2
			// 
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->dataGridViewTextBoxColumn1});
			this->Grid2->Location = System::Drawing::Point(307, 156);
			this->Grid2->Name = L"Grid2";
			this->Grid2->RowTemplate->Height = 24;
			this->Grid2->Size = System::Drawing::Size(253, 312);
			this->Grid2->TabIndex = 10;
			this->Grid2->RowCount = 30;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this->dataGridViewTextBoxColumn1->HeaderText = L"Pila";
			this->dataGridViewTextBoxColumn1->Name = L"dataGridViewTextBoxColumn1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(852, 688);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->btnInsertarNuevoElemento);
			this->Controls->Add(this->txtElemento);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtPosicion);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnApilar);
			this->Controls->Add(this->txtApilar);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnApilar_Click(System::Object^  sender, System::EventArgs^  e) {
				 int A=Convert::ToInt32(txtApilar->Text);
				 if(P1.Pila_llena()==true)
				 {
					 MessageBox::Show("Pila llena");
				 }
				 else
				 {
					 P1.Apilar(A);
					 Grid->Rows[pos++]->Cells[0]->Value=A;
				 }
	}
private: System::Void btnInsertarNuevoElemento_Click(System::Object^  sender, System::EventArgs^  e) {
			 int aux;
			 int pos=Convert::ToInt32(txtPosicion->Text);
			 int elem=Convert::ToInt32(txtElemento->Text);
			 while(P1.Get_tope()>pos-1)
			 {
				 aux=P1.Desapilar();
				 P2.Apilar(aux);
			 }
			 P2.Apilar(elem);
			 int aux2;
			 while(P1.Pila_vacia()==false)
			 {
				 aux2=P1.Desapilar();
				 P2.Apilar(aux2);
			 }
			int aux3;
			while(P2.Pila_vacia()==false)
			{
				int aux3=P2.Desapilar();
				Grid2->Rows[pos2++]->Cells[0]->Value=aux3;
			}

		 }
};
}

