#pragma once
#include <iostream>
#include <string>
using namespace std;
class Auto
{
private:
	int matricula;
	string color;
	double precio;
	double seguro;
	double preciocimp;
public:
	Auto(void);
	int Get_Matricula();
	string Get_Color();
	double Get_Precio();
	double Get_Seguro();
	void Set_Matricula(int mat);
	void Set_Color(string col);
	void Set_Precio(double p);
	void Set_Seguro(double s);
    double calcularseguro();
	double calcularpreciocimp();

};

