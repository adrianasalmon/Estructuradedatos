#include "StdAfx.h"
#include "Auto.h"


Auto::Auto(void)
{
}
int Auto::Get_Matricula()
{
	return matricula;
}
string Auto::Get_Color()
{
	return color;
}
double Auto::Get_Precio()
{
	return precio;
}
double Auto::Get_Seguro()
{
	return seguro;
}
void Auto::Set_Matricula(int mat)
{
	matricula=mat;
}
void Auto::Set_Color(string col)
{
	color=col;
}
void Auto::Set_Precio(double p)
{
	precio=p;
}
void Auto::Set_Seguro(double s)
{
	seguro=s;
}
double Auto::calcularseguro()
{
	seguro=precio*0.01;
	return seguro;
}
double Auto::calcularpreciocimp()
{
	preciocimp=precio+(precio*0.13);
	return preciocimp;
}
