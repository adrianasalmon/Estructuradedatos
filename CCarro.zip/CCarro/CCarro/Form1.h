#pragma once
#include "Auto.h"
#include <iostream>
#include <string>
#include "msclr\marshal_cppstd.h"
namespace CCarro {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::TextBox^  txtMatricula;
	private: System::Windows::Forms::TextBox^  txtColor;
	private: System::Windows::Forms::TextBox^  txtPrecio;
	private: System::Windows::Forms::TextBox^  txtPreciosinseguro;
	private: System::Windows::Forms::TextBox^  txtSeguro;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->txtMatricula = (gcnew System::Windows::Forms::TextBox());
			this->txtColor = (gcnew System::Windows::Forms::TextBox());
			this->txtPrecio = (gcnew System::Windows::Forms::TextBox());
			this->txtPreciosinseguro = (gcnew System::Windows::Forms::TextBox());
			this->txtSeguro = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(77, 48);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(65, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Matricula";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(77, 100);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(41, 17);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Color";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(77, 149);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(48, 17);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Precio";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(77, 277);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(118, 17);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Precio sin seguro";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(77, 330);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(54, 17);
			this->label5->TabIndex = 4;
			this->label5->Text = L"Seguro";
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(138, 193);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(145, 40);
			this->btnCalcular->TabIndex = 5;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// txtMatricula
			// 
			this->txtMatricula->Location = System::Drawing::Point(244, 47);
			this->txtMatricula->Name = L"txtMatricula";
			this->txtMatricula->Size = System::Drawing::Size(123, 22);
			this->txtMatricula->TabIndex = 6;
			// 
			// txtColor
			// 
			this->txtColor->Location = System::Drawing::Point(244, 95);
			this->txtColor->Name = L"txtColor";
			this->txtColor->Size = System::Drawing::Size(123, 22);
			this->txtColor->TabIndex = 7;
			// 
			// txtPrecio
			// 
			this->txtPrecio->Location = System::Drawing::Point(244, 146);
			this->txtPrecio->Name = L"txtPrecio";
			this->txtPrecio->Size = System::Drawing::Size(123, 22);
			this->txtPrecio->TabIndex = 8;
			// 
			// txtPreciosinseguro
			// 
			this->txtPreciosinseguro->Location = System::Drawing::Point(244, 272);
			this->txtPreciosinseguro->Name = L"txtPreciosinseguro";
			this->txtPreciosinseguro->Size = System::Drawing::Size(123, 22);
			this->txtPreciosinseguro->TabIndex = 8;
			// 
			// txtSeguro
			// 
			this->txtSeguro->Location = System::Drawing::Point(244, 327);
			this->txtSeguro->Name = L"txtSeguro";
			this->txtSeguro->Size = System::Drawing::Size(123, 22);
			this->txtSeguro->TabIndex = 9;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(521, 418);
			this->Controls->Add(this->txtSeguro);
			this->Controls->Add(this->txtPreciosinseguro);
			this->Controls->Add(this->txtPrecio);
			this->Controls->Add(this->txtColor);
			this->Controls->Add(this->txtMatricula);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 Auto auto1;
				 auto1.Set_Precio(System::Convert::ToDouble(txtPrecio->Text));
				 double preciosinseguro;
				 preciosinseguro=auto1.calcularpreciocimp();
				 txtPreciosinseguro->Text=System::Convert::ToString(preciosinseguro);
				 double seguro;
				 seguro=auto1.calcularseguro();
				 txtSeguro->Text=System::Convert::ToString(seguro);
			 }
};
}
