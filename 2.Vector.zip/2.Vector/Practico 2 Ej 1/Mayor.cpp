#include "StdAfx.h"
#include "Mayor.h"


Mayor::Mayor(void)
{
	vector[n]=0;
	Tamano=0;
}
int Mayor::Get_Tamano()
{
	return Tamano;
}
void Mayor::Set_Tamano(int tam)
{
	Tamano=tam;
}
double Mayor::Get_Vector(int pos)
{
	return vector[pos];
}
void Mayor::Set_Vector(double valor, int pos)
{
	vector[pos]=valor;
}
double Mayor::Calcular(int pos)
{   double mayor=vector[0];
	for(int i=0; i<pos; i++)
	 {if(mayor <= vector[i])
	   {
		   mayor=vector[i];
       }
     }
	return mayor;
}