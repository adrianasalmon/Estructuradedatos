#pragma once
#include "Mayor.h"
#include <iostream>
namespace Practico2Ej1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	Mayor mayor1;
	int posicion=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::TextBox^  txtNumero;
	private: System::Windows::Forms::TextBox^  txtMayor;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnAgregar;
	private: System::Windows::Forms::Button^  btnMostrar;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->txtNumero = (gcnew System::Windows::Forms::TextBox());
			this->txtMayor = (gcnew System::Windows::Forms::TextBox());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnAgregar = (gcnew System::Windows::Forms::Button());
			this->btnMostrar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(22, 38);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(22, 97);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(44, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Numero";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(22, 341);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(36, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Mayor";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(101, 38);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(106, 20);
			this->txtTamano->TabIndex = 3;
			// 
			// txtNumero
			// 
			this->txtNumero->Location = System::Drawing::Point(101, 97);
			this->txtNumero->Name = L"txtNumero";
			this->txtNumero->Size = System::Drawing::Size(106, 20);
			this->txtNumero->TabIndex = 4;
			// 
			// txtMayor
			// 
			this->txtMayor->Location = System::Drawing::Point(101, 341);
			this->txtMayor->Name = L"txtMayor";
			this->txtMayor->Size = System::Drawing::Size(106, 20);
			this->txtMayor->TabIndex = 5;
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(75, 146);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(240, 150);
			this->Grid->TabIndex = 6;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Numeros";
			this->Column1->Name = L"Column1";
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(253, 38);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(75, 23);
			this->btnDefinir->TabIndex = 7;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// btnAgregar
			// 
			this->btnAgregar->Location = System::Drawing::Point(253, 97);
			this->btnAgregar->Name = L"btnAgregar";
			this->btnAgregar->Size = System::Drawing::Size(75, 23);
			this->btnAgregar->TabIndex = 8;
			this->btnAgregar->Text = L"Agregar";
			this->btnAgregar->UseVisualStyleBackColor = true;
			this->btnAgregar->Click += gcnew System::EventHandler(this, &Form1::btnAgregar_Click);
			// 
			// btnMostrar
			// 
			this->btnMostrar->Location = System::Drawing::Point(253, 341);
			this->btnMostrar->Name = L"btnMostrar";
			this->btnMostrar->Size = System::Drawing::Size(75, 23);
			this->btnMostrar->TabIndex = 9;
			this->btnMostrar->Text = L"Mostrar";
			this->btnMostrar->UseVisualStyleBackColor = true;
			this->btnMostrar->Click += gcnew System::EventHandler(this, &Form1::btnMostrar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(360, 398);
			this->Controls->Add(this->btnMostrar);
			this->Controls->Add(this->btnAgregar);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->txtMayor);
			this->Controls->Add(this->txtNumero);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam=Convert::ToInt32(txtTamano->Text);
				 Grid->RowCount=tam;
			 }
private: System::Void btnAgregar_Click(System::Object^  sender, System::EventArgs^  e) {
			 double numero;
			 numero=Convert::ToDouble(txtNumero->Text);
			 mayor1.Set_Vector(numero, posicion);
			 Grid->Rows[posicion]->Cells[0]->Value=numero;
			 posicion++;
		 }
private: System::Void btnMostrar_Click(System::Object^  sender, System::EventArgs^  e) {
			 double may;
			 may=mayor1.Calcular(posicion);
			 txtMayor->Text=Convert::ToString(may);
		 }
};
}

