#pragma once
#include <iostream>
#include <string>
#include "VPromedio.h"
#include <msclr.\marshal_cppstd.h>


namespace My3Vector {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	VPromedio promedio1;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::TextBox^  txtNumero;
	private: System::Windows::Forms::TextBox^  txtPromedio;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Button^  btnCalcularPromedio;
	private: System::Windows::Forms::DataGridView^  Grilla_Numeros;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->txtNumero = (gcnew System::Windows::Forms::TextBox());
			this->txtPromedio = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->btnCalcularPromedio = (gcnew System::Windows::Forms::Button());
			this->Grilla_Numeros = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla_Numeros))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(31, 39);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(60, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(31, 99);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(58, 17);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Numero";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(31, 158);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(68, 17);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Promedio";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(169, 41);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(113, 22);
			this->txtTamano->TabIndex = 3;
			// 
			// txtNumero
			// 
			this->txtNumero->Location = System::Drawing::Point(169, 94);
			this->txtNumero->Name = L"txtNumero";
			this->txtNumero->Size = System::Drawing::Size(113, 22);
			this->txtNumero->TabIndex = 4;
			// 
			// txtPromedio
			// 
			this->txtPromedio->Location = System::Drawing::Point(169, 153);
			this->txtPromedio->Name = L"txtPromedio";
			this->txtPromedio->Size = System::Drawing::Size(113, 22);
			this->txtPromedio->TabIndex = 5;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(343, 37);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(107, 25);
			this->btnDefinir->TabIndex = 6;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(343, 99);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(107, 25);
			this->btnIngresar->TabIndex = 7;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// btnCalcularPromedio
			// 
			this->btnCalcularPromedio->Location = System::Drawing::Point(329, 153);
			this->btnCalcularPromedio->Name = L"btnCalcularPromedio";
			this->btnCalcularPromedio->Size = System::Drawing::Size(132, 40);
			this->btnCalcularPromedio->TabIndex = 8;
			this->btnCalcularPromedio->Text = L"Calcular Promedio";
			this->btnCalcularPromedio->UseVisualStyleBackColor = true;
			this->btnCalcularPromedio->Click += gcnew System::EventHandler(this, &Form1::btnCalcularPromedio_Click);
			// 
			// Grilla_Numeros
			// 
			this->Grilla_Numeros->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grilla_Numeros->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grilla_Numeros->Location = System::Drawing::Point(82, 239);
			this->Grilla_Numeros->Name = L"Grilla_Numeros";
			this->Grilla_Numeros->RowTemplate->Height = 24;
			this->Grilla_Numeros->Size = System::Drawing::Size(408, 205);
			this->Grilla_Numeros->TabIndex = 9;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Numeros";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(649, 475);
			this->Controls->Add(this->Grilla_Numeros);
			this->Controls->Add(this->btnCalcularPromedio);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtPromedio);
			this->Controls->Add(this->txtNumero);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla_Numeros))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tam;
			 tam=System::Convert::ToInt32(txtTamano->Text);
			 promedio1.Set_Tamano(tam);
			 Grilla_Numeros->RowCount=promedio1.Get_Tamano();
			 pos=0;
			 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			 double elemento;
			 elemento=System::Convert::ToDouble(txtNumero->Text);
			 if (promedio1.Ingresar_Vector(elemento,pos)) 
			 {
				pos++;
				Grilla_Numeros->ColumnCount=1;
				Grilla_Numeros->RowCount=promedio1.Get_Tamano();
				int i=0; 
				double numero;
				for (i=0;i<promedio1.Get_Tamano();i++)
				{
				numero=promedio1.Get_Vector(i);
				Grilla_Numeros->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(numero);
				}
			 }
		 }
			 
private: System::Void btnCalcularPromedio_Click(System::Object^  sender, System::EventArgs^  e) {

			 double Prom;
			 Prom=promedio1.Promedio_Vector();
			 txtPromedio->Text=System::Convert::ToString(Prom);
		 }
};
}

