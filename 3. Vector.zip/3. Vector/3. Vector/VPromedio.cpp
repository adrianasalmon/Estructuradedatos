#include "StdAfx.h"
#include "VPromedio.h"
#include <iostream>
#define MAX 10
using namespace std;

VPromedio::VPromedio(void)
{
	V[MAX]=0;
	tamano=0;
}
double VPromedio::Get_Vector(int posicion)
{
	return V[posicion];
}
void VPromedio::Set_Vector(double elemento,int posicion)
{
	V[posicion]=elemento;
}
int VPromedio::Get_Tamano()
{
	return tamano;
}
void VPromedio::Set_Tamano(int tam)
{
	tamano=tam;
}
bool VPromedio::Lleno_Vector()
{
	if(tamano==(MAX-1))
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool VPromedio::Vacio_Vector()
{
	if(tamano==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool VPromedio::Ingresar_Vector(double elemento,int posicion)
{
	if((posicion<0)&&(posicion>tamano))
	{
		return false;

	}
	else
	{
		if(Lleno_Vector()==true)
		{
			return false;
		}
		else
		{
			int i=Get_Tamano();
			while(i>posicion)
			{
				V[i]=V[i-1];
				i--;
			}
			V[posicion]=elemento;
			return true;
		}
	}
}
double VPromedio::Promedio_Vector()
{
	int Prom=0;
	for(int i=0;i<Get_Tamano();i++)
	{
		Prom=Prom+V[i];
	}
	Prom=Prom/Get_Tamano();
	return Prom;
}
