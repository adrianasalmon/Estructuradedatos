#pragma once
#define MAX 10

class VPromedio
{
private:
	double V[MAX];
	int tamano;
public:
	VPromedio(void);
	double Get_Vector(int posicion);
	void Set_Vector(double elemento,int posicion);
	int Get_Tamano();
	void Set_Tamano(int tam);
	bool Lleno_Vector();
	bool Vacio_Vector();
	bool Ingresar_Vector(double elemento,int posicion);
	double Promedio_Vector();
};

