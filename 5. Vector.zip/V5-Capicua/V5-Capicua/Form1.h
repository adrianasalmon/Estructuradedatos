#pragma once
#include <iostream>
#include"VectorCapicua.h"
#include "string.h"

namespace V5Capicua {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	VectorCapicua VecCapi;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::TextBox^  txtDato;
	private: System::Windows::Forms::Button^  btnTam;
	private: System::Windows::Forms::Button^  btnDato;
	private: System::Windows::Forms::Button^  btnCapi;
	private: System::Windows::Forms::TextBox^  txtCapi;
	private: System::Windows::Forms::DataGridView^  grilla;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->txtDato = (gcnew System::Windows::Forms::TextBox());
			this->btnTam = (gcnew System::Windows::Forms::Button());
			this->btnDato = (gcnew System::Windows::Forms::Button());
			this->btnCapi = (gcnew System::Windows::Forms::Button());
			this->txtCapi = (gcnew System::Windows::Forms::TextBox());
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(26, 34);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(60, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(26, 77);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(38, 17);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Dato";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(98, 31);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(85, 22);
			this->txtTamano->TabIndex = 2;
			// 
			// txtDato
			// 
			this->txtDato->Location = System::Drawing::Point(98, 74);
			this->txtDato->Name = L"txtDato";
			this->txtDato->Size = System::Drawing::Size(85, 22);
			this->txtDato->TabIndex = 3;
			// 
			// btnTam
			// 
			this->btnTam->Location = System::Drawing::Point(213, 30);
			this->btnTam->Name = L"btnTam";
			this->btnTam->Size = System::Drawing::Size(72, 23);
			this->btnTam->TabIndex = 4;
			this->btnTam->Text = L"Aceptar";
			this->btnTam->UseVisualStyleBackColor = true;
			this->btnTam->Click += gcnew System::EventHandler(this, &Form1::btnTam_Click);
			// 
			// btnDato
			// 
			this->btnDato->Location = System::Drawing::Point(213, 74);
			this->btnDato->Name = L"btnDato";
			this->btnDato->Size = System::Drawing::Size(72, 22);
			this->btnDato->TabIndex = 5;
			this->btnDato->Text = L"Ingresar";
			this->btnDato->UseVisualStyleBackColor = true;
			this->btnDato->Click += gcnew System::EventHandler(this, &Form1::btnDato_Click);
			// 
			// btnCapi
			// 
			this->btnCapi->Location = System::Drawing::Point(307, 132);
			this->btnCapi->Name = L"btnCapi";
			this->btnCapi->Size = System::Drawing::Size(73, 28);
			this->btnCapi->TabIndex = 6;
			this->btnCapi->Text = L"Capicua";
			this->btnCapi->UseVisualStyleBackColor = true;
			this->btnCapi->Click += gcnew System::EventHandler(this, &Form1::btnCapi_Click);
			// 
			// txtCapi
			// 
			this->txtCapi->Location = System::Drawing::Point(296, 187);
			this->txtCapi->Name = L"txtCapi";
			this->txtCapi->Size = System::Drawing::Size(85, 22);
			this->txtCapi->TabIndex = 7;
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla->Location = System::Drawing::Point(12, 132);
			this->grilla->Name = L"grilla";
			this->grilla->RowTemplate->Height = 24;
			this->grilla->Size = System::Drawing::Size(240, 150);
			this->grilla->TabIndex = 8;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(392, 314);
			this->Controls->Add(this->grilla);
			this->Controls->Add(this->txtCapi);
			this->Controls->Add(this->btnCapi);
			this->Controls->Add(this->btnDato);
			this->Controls->Add(this->btnTam);
			this->Controls->Add(this->txtDato);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
private: System::Void btnTam_Click(System::Object^  sender, System::EventArgs^  e) {
			 int Tam;
			 Tam=System::Convert::ToInt32(txtTamano->Text);
			 VecCapi.Set_tamano(Tam);
			 grilla->RowCount=VecCapi.Get_tamano();
			 pos=0;
			 }
private: System::Void btnDato_Click(System::Object^  sender, System::EventArgs^  e) {
			double elemento;
			elemento=System::Convert::ToDouble(txtDato->Text);
			if(VecCapi.Ingresar(pos,elemento))
			{
				pos++;
				grilla->ColumnCount=1;
				grilla->ColumnCount=VecCapi.Get_tamano();
				double dato;
				for(int i=0;i<VecCapi.Get_tamano();i++)
				{
					dato=VecCapi.Get_vector(i);
					grilla->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(dato);
				}
			}
		 }
private: System::Void btnCapi_Click(System::Object^  sender, System::EventArgs^  e) {
		 bool capicua;
		 capicua=VecCapi.Capicua();
		 txtCapi->Text=System::Convert::ToString(capicua);
		 }
};
}

