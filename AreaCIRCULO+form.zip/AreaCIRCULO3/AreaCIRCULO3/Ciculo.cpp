#include "StdAfx.h"
#include "Ciculo.h"


Ciculo::Ciculo(void)
{
}
float Ciculo::Get_radio()
{
	return radio;
}
float Ciculo::Get_area()
{
	return area;
}
void Ciculo::Set_radio(float r)
{
	radio=r;
}
void Ciculo::Set_area(float a)
{
	area=a;
}
float Ciculo::Calcular()
{
	area= radio * radio * 3.1416;
	return area;
}