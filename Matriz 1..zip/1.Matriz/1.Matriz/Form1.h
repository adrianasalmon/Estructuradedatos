#pragma once
#include "Mat.h"

namespace My1Matriz {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	Mat M1;
	int posf=0;
	int posc=0;
	Mat M2;
	int pos2f=0;
	int pos2c=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtelemento;
	protected: 
	private: System::Windows::Forms::TextBox^  txtcolumna;
	private: System::Windows::Forms::TextBox^  txtfila;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  btnIng;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::DataGridView^  grillar;
	private: System::Windows::Forms::DataGridView^  grilla;
	private: System::Windows::Forms::Button^  btnRepetidos;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtelemento = (gcnew System::Windows::Forms::TextBox());
			this->txtcolumna = (gcnew System::Windows::Forms::TextBox());
			this->txtfila = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btnIng = (gcnew System::Windows::Forms::Button());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->grillar = (gcnew System::Windows::Forms::DataGridView());
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->btnRepetidos = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillar))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// txtelemento
			// 
			this->txtelemento->Location = System::Drawing::Point(105, 164);
			this->txtelemento->Name = L"txtelemento";
			this->txtelemento->Size = System::Drawing::Size(127, 22);
			this->txtelemento->TabIndex = 16;
			// 
			// txtcolumna
			// 
			this->txtcolumna->Location = System::Drawing::Point(105, 84);
			this->txtcolumna->Name = L"txtcolumna";
			this->txtcolumna->Size = System::Drawing::Size(127, 22);
			this->txtcolumna->TabIndex = 15;
			// 
			// txtfila
			// 
			this->txtfila->Location = System::Drawing::Point(105, 39);
			this->txtfila->Name = L"txtfila";
			this->txtfila->Size = System::Drawing::Size(127, 22);
			this->txtfila->TabIndex = 14;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(35, 167);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(67, 17);
			this->label3->TabIndex = 13;
			this->label3->Text = L"Elemento";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(35, 84);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(70, 17);
			this->label2->TabIndex = 12;
			this->label2->Text = L"Columnas";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(35, 38);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(37, 17);
			this->label1->TabIndex = 11;
			this->label1->Text = L"Filas";
			// 
			// btnIng
			// 
			this->btnIng->Location = System::Drawing::Point(265, 153);
			this->btnIng->Name = L"btnIng";
			this->btnIng->Size = System::Drawing::Size(118, 45);
			this->btnIng->TabIndex = 10;
			this->btnIng->Text = L"Ingresar";
			this->btnIng->UseVisualStyleBackColor = true;
			this->btnIng->Click += gcnew System::EventHandler(this, &Form1::btnIng_Click);
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(265, 51);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(114, 41);
			this->btnDefinir->TabIndex = 9;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// grillar
			// 
			this->grillar->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillar->Location = System::Drawing::Point(39, 439);
			this->grillar->Name = L"grillar";
			this->grillar->RowTemplate->Height = 24;
			this->grillar->Size = System::Drawing::Size(324, 179);
			this->grillar->TabIndex = 19;
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Location = System::Drawing::Point(38, 214);
			this->grilla->Name = L"grilla";
			this->grilla->RowTemplate->Height = 24;
			this->grilla->Size = System::Drawing::Size(326, 177);
			this->grilla->TabIndex = 18;
			// 
			// btnRepetidos
			// 
			this->btnRepetidos->Location = System::Drawing::Point(393, 262);
			this->btnRepetidos->Name = L"btnRepetidos";
			this->btnRepetidos->Size = System::Drawing::Size(116, 51);
			this->btnRepetidos->TabIndex = 17;
			this->btnRepetidos->Text = L"Eliminar repetidos";
			this->btnRepetidos->UseVisualStyleBackColor = true;
			this->btnRepetidos->Click += gcnew System::EventHandler(this, &Form1::btnRepetidos_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(699, 679);
			this->Controls->Add(this->grillar);
			this->Controls->Add(this->grilla);
			this->Controls->Add(this->btnRepetidos);
			this->Controls->Add(this->txtelemento);
			this->Controls->Add(this->txtcolumna);
			this->Controls->Add(this->txtfila);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnIng);
			this->Controls->Add(this->btnDefinir);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillar))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
		int fila;int columna;
		 columna=System::Convert::ToInt32(txtcolumna->Text);
		 fila=System::Convert::ToInt32(txtfila->Text);
		 M1.Set_fil(fila);
		 M1.Set_col(columna);
		 grilla->ColumnCount=columna;
		 grilla->RowCount=fila;
			 }
private: System::Void btnIng_Click(System::Object^  sender, System::EventArgs^  e) {
		int ele;
		 ele=System::Convert::ToInt32(txtelemento->Text);
		 M1.Set_Matriz(posf,posc,ele);
		 if(M1.LLena())
		 {

		  MessageBox::Show("Esta llena");
		 }
		 else
		 {
			grilla->Rows[posf]->Cells[posc]->Value=M1.Get_Matriz(posf,posc);
			if(posc==M1.Get_col()-1)
			{
			posc=0;
			posf++;
			}
			else
			{
			posc++;
			}
		 }
		 }
private: System::Void btnRepetidos_Click(System::Object^  sender, System::EventArgs^  e) {
			 Mat M3;
			 M3=M3.Repetidos(M1);
			 grillar->RowCount=M3.Get_fil();
			 grillar->ColumnCount=M3.Get_col();
		  while(pos2f<M3.Get_fil())
		  {
			  grillar->Rows[pos2f]->Cells[pos2c]->Value=M3.Get_Matriz(pos2f,pos2c);
				if(pos2c==M3.Get_col()-1)
				{
					pos2c=0;
					pos2f++;
				}
				else
				{
					pos2c++;
				}
		  }
		 }
};
}

