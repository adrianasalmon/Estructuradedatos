#include "StdAfx.h"
#include "Mat.h"


Mat::Mat(void)
{ col=0;
 fil=0;
 Matriz[a][b]=0;
}
int Mat::Get_fil()
{ return fil;
}
void Mat::Set_fil(int f)
    { fil=f;
	}
int Mat::Get_col()
	{ return col;
	}
void Mat::Set_col(int c)
	{ col=c;
	}
int Mat::Get_Matriz(int posf, int posc)
	{ return Matriz[posf][posc];
	}
void Mat::Set_Matriz(int posf, int posc, int ele)
	{ Matriz[posf][posc]=ele;
	}

bool Mat::LLena()
{
	if (fil==a-1 && col==b-1)
	{
		return true;
	}
	else
	{
		return false;
	}

}
bool Mat::Vacia()
{
	if(fil==0 && col==0)
		{
	return true;
}
else
	{
		return false;
	}

}
Mat Mat::Repetidos(Mat M1)
{
	Mat Maux;
	Mat M2;
	Maux.Set_fil(M1.Get_fil());
	Maux.Set_col(M1.Get_col());
	M2.Set_fil(M1.Get_fil());
	M2.Set_col(M1.Get_col());
	int jf=0;
	int jc=0;
	int zf=0;
	int zc=0;

	for(int f=0;f<M1.Get_fil();f++)
	{
		for(int c=0;c<M1.Get_col();c++)
		{ 
			int cont=0;
			int num=M1.Get_Matriz(f,c);
			Maux.Set_Matriz(jf,jc,num);
			if(jc==Maux.Get_col()-1)
			{
			jc=0;
			jf++;
			}
			else
			{
			jc++;
			}
			for(int kf=0;kf<M1.Get_fil();kf++)
			{
				for(int kc=0;kc<M1.Get_col();kc++)
				{		 
					if(Maux.Get_Matriz(kf,kc)==num)
					{
						cont++;
					}

				}
			}
			if(cont==1)
			{
				M2.Set_Matriz(zf,zc,num);
				if(zc==M1.Get_col()-1)
				{
				zc=0;
				zf++;
				}
				else
				{
				zc++;
				}
			}
		}
	}
	return M2;
}