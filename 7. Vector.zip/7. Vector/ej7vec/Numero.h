#pragma once
#include <string>
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>

#define n 50

using namespace std;


 class Numero
{
private:
	int vector[n];
	int Tamano;
public:
	Numero(void);
	int Get_Tamano();
	void Set_Tamano(int x);
	int Get_vector(int y);
	void Set_vector(int x, int y);
	string agregar(int x);
	
	
};



