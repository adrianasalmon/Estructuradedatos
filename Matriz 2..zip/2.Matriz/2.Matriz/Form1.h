#pragma once
#include "Mat.h"
namespace My2Matriz {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	Mat M1;
	int posf=0;
	int posc=0;
	Mat M2;
	int pos2f=0;
	int pos2c=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtMTS;
	protected: 
	private: System::Windows::Forms::DataGridView^  grilla;
	private: System::Windows::Forms::TextBox^  txtelemento;
	private: System::Windows::Forms::TextBox^  txtcolumna;
	private: System::Windows::Forms::TextBox^  txtfila;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  btnIng;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnMTS;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtMTS = (gcnew System::Windows::Forms::TextBox());
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->txtelemento = (gcnew System::Windows::Forms::TextBox());
			this->txtcolumna = (gcnew System::Windows::Forms::TextBox());
			this->txtfila = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btnIng = (gcnew System::Windows::Forms::Button());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnMTS = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// txtMTS
			// 
			this->txtMTS->Location = System::Drawing::Point(439, 135);
			this->txtMTS->Name = L"txtMTS";
			this->txtMTS->Size = System::Drawing::Size(127, 22);
			this->txtMTS->TabIndex = 22;
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Location = System::Drawing::Point(17, 263);
			this->grilla->Name = L"grilla";
			this->grilla->RowTemplate->Height = 24;
			this->grilla->Size = System::Drawing::Size(326, 177);
			this->grilla->TabIndex = 21;
			// 
			// txtelemento
			// 
			this->txtelemento->Location = System::Drawing::Point(84, 189);
			this->txtelemento->Name = L"txtelemento";
			this->txtelemento->Size = System::Drawing::Size(127, 22);
			this->txtelemento->TabIndex = 20;
			// 
			// txtcolumna
			// 
			this->txtcolumna->Location = System::Drawing::Point(84, 109);
			this->txtcolumna->Name = L"txtcolumna";
			this->txtcolumna->Size = System::Drawing::Size(127, 22);
			this->txtcolumna->TabIndex = 19;
			// 
			// txtfila
			// 
			this->txtfila->Location = System::Drawing::Point(84, 64);
			this->txtfila->Name = L"txtfila";
			this->txtfila->Size = System::Drawing::Size(127, 22);
			this->txtfila->TabIndex = 18;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(14, 192);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(67, 17);
			this->label3->TabIndex = 17;
			this->label3->Text = L"Elemento";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(14, 109);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(70, 17);
			this->label2->TabIndex = 16;
			this->label2->Text = L"Columnas";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(14, 63);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(37, 17);
			this->label1->TabIndex = 15;
			this->label1->Text = L"Filas";
			// 
			// btnIng
			// 
			this->btnIng->Location = System::Drawing::Point(244, 178);
			this->btnIng->Name = L"btnIng";
			this->btnIng->Size = System::Drawing::Size(118, 45);
			this->btnIng->TabIndex = 13;
			this->btnIng->Text = L"Ingresar";
			this->btnIng->UseVisualStyleBackColor = true;
			this->btnIng->Click += gcnew System::EventHandler(this, &Form1::btnIng_Click);
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(244, 76);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(114, 41);
			this->btnDefinir->TabIndex = 12;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// btnMTS
			// 
			this->btnMTS->Location = System::Drawing::Point(589, 105);
			this->btnMTS->Name = L"btnMTS";
			this->btnMTS->Size = System::Drawing::Size(114, 83);
			this->btnMTS->TabIndex = 23;
			this->btnMTS->Text = L"Numeros Elementos MTS";
			this->btnMTS->UseVisualStyleBackColor = true;
			this->btnMTS->Click += gcnew System::EventHandler(this, &Form1::btnMTS_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(734, 512);
			this->Controls->Add(this->btnMTS);
			this->Controls->Add(this->txtMTS);
			this->Controls->Add(this->grilla);
			this->Controls->Add(this->txtelemento);
			this->Controls->Add(this->txtcolumna);
			this->Controls->Add(this->txtfila);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnIng);
			this->Controls->Add(this->btnDefinir);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
		 int fila;int columna;
		 columna=System::Convert::ToInt32(txtcolumna->Text);
		 fila=System::Convert::ToInt32(txtfila->Text);
		 M1.Set_fil(fila);
		 M1.Set_col(columna);
		 grilla->ColumnCount=columna;
		 grilla->RowCount=fila;
			 }
private: System::Void btnIng_Click(System::Object^  sender, System::EventArgs^  e) {
		 int ele;
		 ele=System::Convert::ToInt32(txtelemento->Text);
		 M1.Set_Matriz(posf,posc,ele);
		 if(M1.LLena())
		 {

		  MessageBox::Show("Esta llena");
		 }
		 else
		 {
			grilla->Rows[posf]->Cells[posc]->Value=M1.Get_Matriz(posf,posc);
			if(posc==M1.Get_col()-1)
			{
			posc=0;
			posf++;
			}
			else
			{
			posc++;
			}
		 }
		 }
private: System::Void btnMTS_Click(System::Object^  sender, System::EventArgs^  e) {
		int MTS;
		 MTS=M1.contmatriztrisup();
		 if(M1.matriztrisup()==false)
		 {
		  MessageBox::Show("No es una matriz triangular superior");
		 }
		 else
		 {
			txtMTS->Text=System::Convert::ToString(MTS);
		 }
		 } 
		 
};
}

