#include "StdAfx.h"
#include <iostream>
#include "Vector.h"

using namespace std;

Vector::Vector(void)
{
	vec[100]=0;
	n=0;
}


Vector::~Vector(void)
{
}

void Vector::cargarVector(int vec[], int n){
	for(int i=0;i<n;i++){
		cout<<"nota["<<i<<"] =" ;
		cin>>vec[i];
	}
}
void Vector::ordenarVector(int vec[], int n){
	int aux;
	for(int i=0; i<(n-1); i++){
		for(int j=i; j<n; j++){
			if(vec[i] < vec[j]){
				aux = vec[i];
				vec[i] = vec[j];
				vec[j] = aux;
			}
		}
	}cout<<"Mejores 3 notas: "<<vec[0]<<","<<vec[1]<<","<<vec[2]<<endl;
}