#include "StdAfx.h"
#include "VInvertido.h"
#include <iostream>
#define MAX 10
using namespace std;

VInvertido::VInvertido(void)
{
	V[MAX]=0;
	tamano=0;
}

double VInvertido::Get_Vector(int posicion)
{
	return V[posicion];
}
void VInvertido::Set_Vector(double elemento, int posicion)
{
	V[posicion]=elemento;
}
int VInvertido::Get_Tamano()
{
	return tamano;
}
void VInvertido::Set_Tamano(int tam)
{
	tamano=tam;
}
bool VInvertido::Lleno_Vector()
{
	if(tamano==(MAX-1))
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool VInvertido::Vacio_Vector()
{
	if(tamano==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool VInvertido::Ingresar_Vector(double elemento,int posicion)
{
	if((posicion<0)&&(posicion>tamano))
	{
		return false;
	}
	else
	{
		if(Lleno_Vector()==true)
		{
			return false;
		}
		else
		{
			int i=Get_Tamano();
			if(i>posicion)
			{
				V[i]=V[i-1];
				i--;
			}
			V[posicion]=elemento;
			return true;
		}
	}

}
void VInvertido::Invertir_Vector()
{
	int aux;
	int tam=Get_Tamano();
	for(int k=0;k<tam/2;k++)
	{
		aux=V[k];
		V[k]=V[tam-1-k];
		V[tam-1-k]=aux;
	}
}
