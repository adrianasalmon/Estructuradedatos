#include "StdAfx.h"
#include "Instrumento.h"

Instrumento::Instrumento(void)
{
	
}
string Instrumento::Get_Tipo()
{
	return tipo;
}
string Instrumento::Get_Descripcion()
{
	return descripcion;
}
double Instrumento::Get_Precio()
{
	return precio;
}

void Instrumento::Set_Tipo(string tip)
{
	tipo=tip;
}
void Instrumento::Set_Descripcion(string descrip)
{
	descripcion=descrip;
}
void Instrumento::Set_Precio(double prec)
{
	precio=prec;
}
void Instrumento::calculardescuentocomp(double cantidad)
{
	descuentocomp=precio* 0.20 * cantidad;
	
}
void Instrumento::calculartotalapagar(double cantidad)
{
	totalapagar=precio*cantidad-(precio*cantidad*0.20);
}
	
double Instrumento::desccomp()
{
	return descuentocomp;
}
double Instrumento::totalpagar()
{
	return totalapagar;
}