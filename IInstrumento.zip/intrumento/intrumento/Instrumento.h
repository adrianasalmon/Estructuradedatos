#pragma once
#include <iostream>
#include <string>
using namespace std;
 class Instrumento
{
private:
	string tipo;
	string descripcion;
	double precio;
	double descuentocomp;
	double totalapagar;
public:
	Instrumento(void);
	string Get_Tipo();
	string Get_Descripcion();
	double Get_Precio();
	void Set_Tipo(string tip);
	void Set_Descripcion(string descrip);
	void Set_Precio(double prec);
	void calculardescuentocomp(double cantidad);
	void calculartotalapagar(double cantidad);
	double desccomp();
	double totalpagar();
};

