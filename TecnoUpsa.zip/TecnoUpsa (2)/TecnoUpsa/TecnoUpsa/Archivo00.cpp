#include "StdAfx.h"
#include "Archivo00.h"
#include "Archivo.h"
Archivo A1;

Archivo00::Archivo00(Archivo archif)
	archi=archif;
}

/*void Archivo00::MostarArchivo(NroReg)
{
	cout << endl << nroReg << ".-  " << archi->Get_nombre() << " \n " << archi->Get_correo() << " \n " << archi->Get_direccion() << " \n " << archi->Get_telefono()<< " \n "<<archi->Get_Pedido() << "  ";
}*/
void Archivo00::adicionarNuevo()
{
	ofstream fsalida(ArchivoF, ios::app | ios::binary);	
		archi = new Archivo();
		//A1.Set_Archivo(archi);
		archi->guardarArchivo(fsalida);	
		fsalida.close();
}
void Archivo00::listar()
{
	archi=new Archivo();
	ifstream fentrada(ArchivoF, ios::in | ios::binary);
}
