#include "StdAfx.h"
#include "Archivo.h"
Archivo::Archivo(void) {
	nombre="";
	correo="";
	direccion="";
	telefono=0;
}
void Archivo::Set_Archivo(Archivo A) {
	nombre = Get_nombre() ;
	correo = Get_correo() ;
	direccion = Get_direccion () ;
	telefono = Get_telefono() ;
	Pedido = Get_Pedido();
}
string Archivo::Get_nombre() {
	return nombre;
}
void Archivo::Set_nombre(string nom){
	nombre=nom;
}
string Archivo::Get_correo() {
	return correo;
}
void Archivo::Set_correo(string cor){
	correo = cor;
}
string Archivo::Get_direccion() {
	return direccion;
}
void Archivo::Set_direccion(string dir){
	direccion = dir;
}
double Archivo::Get_telefono(){
	return telefono;
}
void Archivo::Set_telefono(double tel){
	telefono = tel;
}
Cola Archivo::Get_Pedido() {
	return Pedido;
}
void Archivo::Set_Pedido(Cola ped){
	Pedido = ped;
}
void Archivo::guardarArchivo(ofstream& fsalida) {
	fsalida.write(reinterpret_cast<char*>(&nombre), sizeof(nombre));
	fsalida.write(reinterpret_cast<char*>(&correo), sizeof(correo));
	fsalida.write(reinterpret_cast<char*>(&direccion), sizeof(direccion));
	fsalida.write(reinterpret_cast<char*>(&telefono), sizeof(telefono));
	fsalida.write(reinterpret_cast<char*>(&Pedido), sizeof(Pedido));
}
bool Archivo::leerArchivo(ifstream &fentrada)
{
	bool k = false;
	if (fentrada.is_open() == true) 
	{
		fentrada.read(reinterpret_cast<char *>(&nombre), sizeof(nombre));
		if (fentrada.eof() == false) 
		{				
			fentrada.read(reinterpret_cast<char *>(&correo), sizeof(correo));
			fentrada.read(reinterpret_cast<char *>(&direccion), sizeof(direccion));
			fentrada.read(reinterpret_cast<char *>(&telefono), sizeof(telefono));
			fentrada.read(reinterpret_cast<char *>(&Pedido), sizeof(Pedido));
			k = true;
		}
		else
		{
			cout << endl << "Registro no existe";
		}
	}
	else 
	{
		cout << endl << "Arhivo no existe";
	}
	return(k);
}
