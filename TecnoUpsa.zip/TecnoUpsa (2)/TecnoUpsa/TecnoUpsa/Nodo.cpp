#include "StdAfx.h"
#include "Nodo.h"
Nodo::Nodo(void) {}
int Nodo::Get_Codigo() {
	return Codigo;
}
void Nodo::Set_Codigo(int Cod) {
	Codigo = Cod;
}
int Nodo::Get_Cantidad() {
	return Cantidad;
}
void Nodo::Set_Cantidad(int Can) {
	Cantidad = Can;
}