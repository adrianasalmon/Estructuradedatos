#pragma once
#include "MyForm.h"
#include "Cola.h"
#include "string"
#include "Nodo.h"
#include "msclr\marshal_cppstd.h"
#include "Archivo.h"
#include "ABMarchivo.cpp"

namespace TecnoUpsa {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	Cola C1;
	Nodo N1;
	Archivo Ar1;
	ABMarchivo *abmar = new ABMarchivo("pedido.dat");
	int pos = 0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::RadioButton^  rbBanc;
	protected: 
	private: System::Windows::Forms::RadioButton^  rbEfec;
	private: System::Windows::Forms::TextBox^  txtDireccion;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Button^  btnElim;
	private: System::Windows::Forms::Button^  btnPedir;
	private: System::Windows::Forms::TextBox^  txtCorreo;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::TextBox^  txtCel;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::TextBox^  txtNom;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Button^  btnAgregar;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::TextBox^  txtCantidad;
	private: System::Windows::Forms::TextBox^  txtCodigo;
	private: System::Windows::Forms::Button^  btnProd;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->rbBanc = (gcnew System::Windows::Forms::RadioButton());
			this->rbEfec = (gcnew System::Windows::Forms::RadioButton());
			this->txtDireccion = (gcnew System::Windows::Forms::TextBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->btnElim = (gcnew System::Windows::Forms::Button());
			this->btnPedir = (gcnew System::Windows::Forms::Button());
			this->txtCorreo = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->txtCel = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->txtNom = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->btnAgregar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtCantidad = (gcnew System::Windows::Forms::TextBox());
			this->txtCodigo = (gcnew System::Windows::Forms::TextBox());
			this->btnProd = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// rbBanc
			// 
			this->rbBanc->AutoSize = true;
			this->rbBanc->Location = System::Drawing::Point(637, 134);
			this->rbBanc->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->rbBanc->Name = L"rbBanc";
			this->rbBanc->Size = System::Drawing::Size(69, 21);
			this->rbBanc->TabIndex = 81;
			this->rbBanc->TabStop = true;
			this->rbBanc->Text = L"Banco";
			this->rbBanc->UseVisualStyleBackColor = true;
			// 
			// rbEfec
			// 
			this->rbEfec->AutoSize = true;
			this->rbEfec->Location = System::Drawing::Point(637, 106);
			this->rbEfec->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->rbEfec->Name = L"rbEfec";
			this->rbEfec->Size = System::Drawing::Size(79, 21);
			this->rbEfec->TabIndex = 80;
			this->rbEfec->TabStop = true;
			this->rbEfec->Text = L"Efectivo";
			this->rbEfec->UseVisualStyleBackColor = true;
			// 
			// txtDireccion
			// 
			this->txtDireccion->Location = System::Drawing::Point(672, 310);
			this->txtDireccion->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->txtDireccion->Name = L"txtDireccion";
			this->txtDireccion->Size = System::Drawing::Size(132, 22);
			this->txtDireccion->TabIndex = 79;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(580, 314);
			this->label9->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(67, 17);
			this->label9->TabIndex = 78;
			this->label9->Text = L"Direcci�n";
			// 
			// btnElim
			// 
			this->btnElim->Location = System::Drawing::Point(584, 343);
			this->btnElim->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->btnElim->Name = L"btnElim";
			this->btnElim->Size = System::Drawing::Size(100, 54);
			this->btnElim->TabIndex = 77;
			this->btnElim->Text = L"Eliminar Pedido";
			this->btnElim->UseVisualStyleBackColor = true;
			this->btnElim->Click += gcnew System::EventHandler(this, &Form1::btnElim_Click);
			// 
			// btnPedir
			// 
			this->btnPedir->Location = System::Drawing::Point(719, 343);
			this->btnPedir->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->btnPedir->Name = L"btnPedir";
			this->btnPedir->Size = System::Drawing::Size(100, 54);
			this->btnPedir->TabIndex = 76;
			this->btnPedir->Text = L"Ingresar Pedido";
			this->btnPedir->UseVisualStyleBackColor = true;
			this->btnPedir->Click += gcnew System::EventHandler(this, &Form1::btnPedir_Click);
			// 
			// txtCorreo
			// 
			this->txtCorreo->Location = System::Drawing::Point(672, 278);
			this->txtCorreo->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->txtCorreo->Name = L"txtCorreo";
			this->txtCorreo->Size = System::Drawing::Size(132, 22);
			this->txtCorreo->TabIndex = 75;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(580, 282);
			this->label7->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(51, 17);
			this->label7->TabIndex = 74;
			this->label7->Text = L"Correo";
			// 
			// txtCel
			// 
			this->txtCel->Location = System::Drawing::Point(672, 246);
			this->txtCel->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->txtCel->Name = L"txtCel";
			this->txtCel->Size = System::Drawing::Size(132, 22);
			this->txtCel->TabIndex = 73;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(580, 250);
			this->label8->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(52, 17);
			this->label8->TabIndex = 72;
			this->label8->Text = L"Celular";
			// 
			// txtNom
			// 
			this->txtNom->Location = System::Drawing::Point(672, 215);
			this->txtNom->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->txtNom->Name = L"txtNom";
			this->txtNom->Size = System::Drawing::Size(132, 22);
			this->txtNom->TabIndex = 71;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(580, 218);
			this->label6->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(58, 17);
			this->label6->TabIndex = 70;
			this->label6->Text = L"Nombre";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(668, 194);
			this->label5->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(45, 17);
			this->label5->TabIndex = 69;
			this->label5->Text = L"Datos";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(635, 73);
			this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(116, 17);
			this->label4->TabIndex = 68;
			this->label4->Text = L"Procesar el pago";
			// 
			// btnAgregar
			// 
			this->btnAgregar->Location = System::Drawing::Point(185, 121);
			this->btnAgregar->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->btnAgregar->Name = L"btnAgregar";
			this->btnAgregar->Size = System::Drawing::Size(100, 28);
			this->btnAgregar->TabIndex = 67;
			this->btnAgregar->Text = L"Agregar";
			this->btnAgregar->UseVisualStyleBackColor = true;
			this->btnAgregar->Click += gcnew System::EventHandler(this, &Form1::btnAgregar_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(3) {this->Column1, this->Column2, 
				this->Column3});
			this->Grid->Location = System::Drawing::Point(59, 156);
			this->Grid->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(455, 185);
			this->Grid->TabIndex = 66;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Producto";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Cantidad";
			this->Column2->Name = L"Column2";
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Precio";
			this->Column3->Name = L"Column3";
			// 
			// txtCantidad
			// 
			this->txtCantidad->Location = System::Drawing::Point(249, 89);
			this->txtCantidad->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->txtCantidad->Name = L"txtCantidad";
			this->txtCantidad->Size = System::Drawing::Size(132, 22);
			this->txtCantidad->TabIndex = 65;
			// 
			// txtCodigo
			// 
			this->txtCodigo->Location = System::Drawing::Point(77, 89);
			this->txtCodigo->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->txtCodigo->Name = L"txtCodigo";
			this->txtCodigo->Size = System::Drawing::Size(132, 22);
			this->txtCodigo->TabIndex = 64;
			// 
			// btnProd
			// 
			this->btnProd->Location = System::Drawing::Point(59, 18);
			this->btnProd->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->btnProd->Name = L"btnProd";
			this->btnProd->Size = System::Drawing::Size(199, 32);
			this->btnProd->TabIndex = 63;
			this->btnProd->Text = L"Ver la lista de productos";
			this->btnProd->UseVisualStyleBackColor = true;
			this->btnProd->Click += gcnew System::EventHandler(this, &Form1::btnProd_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(115, 58);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(52, 17);
			this->label1->TabIndex = 82;
			this->label1->Text = L"Codigo";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(292, 58);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(64, 17);
			this->label2->TabIndex = 83;
			this->label2->Text = L"Cantidad";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(881, 405);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->rbBanc);
			this->Controls->Add(this->rbEfec);
			this->Controls->Add(this->txtDireccion);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->btnElim);
			this->Controls->Add(this->btnPedir);
			this->Controls->Add(this->txtCorreo);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->txtCel);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->txtNom);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->btnAgregar);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->txtCantidad);
			this->Controls->Add(this->txtCodigo);
			this->Controls->Add(this->btnProd);
			this->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnProd_Click(System::Object^  sender, System::EventArgs^  e) {
				 MyForm^ Lista_Productos = gcnew MyForm();
				 Lista_Productos->ShowDialog();
			 }
private: System::Void btnAgregar_Click(System::Object^  sender, System::EventArgs^  e) {
			 Grid->RowCount = 3;
		
		if (C1.Lleno())
			MessageBox::Show("No se pueden agregar mas productos");
		else
		{
			int Cod = Convert::ToInt32(txtCodigo->Text);
			N1.Set_Codigo(Cod);
			int Cant = Convert::ToInt32(txtCantidad->Text);
			N1.Set_Cantidad(Cant);
			C1.Enolar(N1);
			if (Cod == 101)
			{
				Grid->Rows[pos]->Cells[0]->Value = "Barbijo";
				Grid->Rows[pos]->Cells[1]->Value = Cant;
				Grid->Rows[pos]->Cells[2]->Value = Cant * 8;
				Grid->Rows[2]->Cells[0]->Value = "TOTAL";
				Grid->Rows[2]->Cells[1]->Value = Cant + System::Convert::ToInt32(Grid->Rows[2]->Cells[1]->Value);
				Grid->Rows[2]->Cells[2]->Value = Cant * 8 + System::Convert::ToInt32(Grid->Rows[2]->Cells[2]->Value);
				pos++;
			}
			else
			{
				if (Cod == 201)
				{
					Grid->Rows[pos]->Cells[0]->Value = "Filtro";
					Grid->Rows[pos]->Cells[1]->Value = Cant;
					Grid->Rows[pos]->Cells[2]->Value = Cant * 2;
					Grid->Rows[2]->Cells[0]->Value = "TOTAL";
					Grid->Rows[2]->Cells[1]->Value = Cant + System::Convert::ToInt32(Grid->Rows[2]->Cells[1]->Value);
					Grid->Rows[2]->Cells[2]->Value = Cant * 2 + System::Convert::ToInt32(Grid->Rows[2]->Cells[2]->Value);
					pos++;
				}
				else
					MessageBox::Show("El producto no existe");
			}
			
		}
		 }
private: System::Void btnElim_Click(System::Object^  sender, System::EventArgs^  e) {
			 MessageBox::Show("Pedido eliminado, hasta luego");
			 Close();
		 }
private: System::Void btnPedir_Click(System::Object^  sender, System::EventArgs^  e) {
	if (C1.Vacio() == true || Convert::ToString(txtNom->Text)== "" || Convert::ToString(txtCel->Text) == "" || Convert::ToString(txtCorreo->Text) == "" || Convert::ToString(txtDireccion->Text) == "")
		MessageBox::Show("No se puede ingresar pedido, por favor llene todos los datos");
	else
	{
		MessageBox::Show("Pedido ingresado correctamente, nos pondremosen contacto contigo pronto");
		string Nom = marshal_as<std::string>(Convert::ToString(txtNom->Text));
		double Cel = Convert::ToDouble(txtCel->Text);
		string Dir = marshal_as<std::string>(Convert::ToString(txtDireccion->Text));
		string Cor = marshal_as<std::string>(Convert::ToString(txtCorreo->Text));
		Ar1.Set_nombre(Nom);
		Ar1.Set_correo(Cor);
		Ar1.Set_direccion(Dir);
		Ar1.Set_telefono(Cel);
		Ar1.Set_Pedido(C1);
		abmar->adicionarNuevo(Ar1);

		Close();
	}
		 }
};
}

