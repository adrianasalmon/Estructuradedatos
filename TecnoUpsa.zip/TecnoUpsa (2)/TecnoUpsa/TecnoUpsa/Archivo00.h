#pragma once
#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include <string>
#include "Archivo.h"

using namespace std;

class Archivo00
{
private:
	string ArchivoF;
	Archivo *archi;

public:
	Archivo00(Archivo archif);
	//void MostarArchivo(NroReg);
	void adicionarNuevo();
	void listar();


};

