#pragma once
class Nodo
{
protected:
	int Codigo;
	int Cantidad;
public:
	Nodo(void);
	int Get_Codigo();
	void Set_Codigo(int Cod);
	int Get_Cantidad();
	void Set_Cantidad(int Can);
};

