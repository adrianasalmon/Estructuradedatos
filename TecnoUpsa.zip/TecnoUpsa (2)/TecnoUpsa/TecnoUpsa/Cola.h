#pragma once
#include "Nodo.h"
int const Max = 2;

class Cola :public Nodo
{
public:
	Nodo C[Max];
	int frente;
	int final;
public:
	Cola(void);
	void Enolar(Nodo x);
	Nodo Desencolar();
	bool Lleno();
	bool Vacio();
};