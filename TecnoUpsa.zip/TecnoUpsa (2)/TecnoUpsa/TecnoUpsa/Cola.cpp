#include "StdAfx.h"
#include "Cola.h"

Cola::Cola(void) {
	final = -1;
	frente = 0;

}
void Cola::Enolar(Nodo x) {
	C[++final] = x;
}
Nodo Cola::Desencolar() {
	Nodo a = C[frente++];
	return a;
}
bool Cola::Lleno() {
	if (final==Max-1)
		return true;
}
bool Cola::Vacio() {
	if (frente>final)
		return true;
}
