#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include "Cola.h"

using namespace std;

class Archivo : public Cola
{
private:
	string nombre;
	string correo;
	string direccion;
	double telefono;
	Cola Pedido;
public:
	Archivo(void);
	void Set_Archivo(Archivo A2);
	string Get_nombre();
	void Set_nombre(string nom);
	string Get_correo();
	void Set_correo(string cor);
	string Get_direccion();
	void Set_direccion(string dir);
	double Get_telefono();
	void Set_telefono(double tel);
	Cola Get_Pedido();
	void Set_Pedido(Cola ped);
	void guardarArchivo(ofstream& fsalida);
	bool leerArchivo(ifstream &fentrada);

};

