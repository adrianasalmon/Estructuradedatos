#pragma once
#include <iostream>
#include "stdafx.h"
#include "Vector.h"
namespace P2EJ4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;


Vector v1;
	int pos=0;
	

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::TextBox^  txtNum;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnAgregar;
	private: System::Windows::Forms::DataGridView^  Grid;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;


	private: System::Windows::Forms::Button^  btnRev;
	private: System::Windows::Forms::DataGridView^  Grid2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn1;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->txtNum = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnAgregar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnRev = (gcnew System::Windows::Forms::Button());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->dataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(47, 45);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(47, 102);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(49, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Numeros";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(112, 42);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(100, 20);
			this->txtTamano->TabIndex = 2;
			// 
			// txtNum
			// 
			this->txtNum->Location = System::Drawing::Point(112, 99);
			this->txtNum->Name = L"txtNum";
			this->txtNum->Size = System::Drawing::Size(100, 20);
			this->txtNum->TabIndex = 3;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(288, 40);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(75, 23);
			this->btnDefinir->TabIndex = 4;
			this->btnDefinir->Text = L"definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// btnAgregar
			// 
			this->btnAgregar->Location = System::Drawing::Point(288, 97);
			this->btnAgregar->Name = L"btnAgregar";
			this->btnAgregar->Size = System::Drawing::Size(75, 23);
			this->btnAgregar->TabIndex = 5;
			this->btnAgregar->Text = L"Agregar";
			this->btnAgregar->UseVisualStyleBackColor = true;
			this->btnAgregar->Click += gcnew System::EventHandler(this, &Form1::btnAgregar_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(112, 210);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(148, 150);
			this->Grid->TabIndex = 6;
			this->Grid->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::dataGridView1_CellContentClick);
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Vector";
			this->Column1->Name = L"Column1";
			// 
			// btnRev
			// 
			this->btnRev->Location = System::Drawing::Point(408, 97);
			this->btnRev->Name = L"btnRev";
			this->btnRev->Size = System::Drawing::Size(75, 23);
			this->btnRev->TabIndex = 8;
			this->btnRev->Text = L"Revertir";
			this->btnRev->UseVisualStyleBackColor = true;
			this->btnRev->Click += gcnew System::EventHandler(this, &Form1::btnRev_Click);
			// 
			// Grid2
			// 
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->dataGridViewTextBoxColumn1});
			this->Grid2->Location = System::Drawing::Point(288, 210);
			this->Grid2->Name = L"Grid2";
			this->Grid2->Size = System::Drawing::Size(148, 150);
			this->Grid2->TabIndex = 9;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this->dataGridViewTextBoxColumn1->HeaderText = L"Vector";
			this->dataGridViewTextBoxColumn1->Name = L"dataGridViewTextBoxColumn1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(527, 479);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->btnRev);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnAgregar);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtNum);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }
private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
int Tam;
Tam= System::Convert::ToInt32 (txtTamano->Text);
v1.Set_tamano(Tam);
Grid->RowCount=Tam;
Grid2->RowCount=Tam;

		 }
private: System::Void btnAgregar_Click(System::Object^  sender, System::EventArgs^  e) {
int numero ;
numero= System::Convert::ToInt32 (txtNum->Text);
v1.Set_vec(numero, pos);
Grid->Rows[pos]->Cells [0]->Value=numero;
pos++;


		 }
private: System::Void btnRev_Click(System::Object^  sender, System::EventArgs^  e) {
			 v1.Ordenar (pos);
			 int aux1;
			 for (int i=0;i<pos;i++)
			 {
			 int aux1= v1.Get_vec2(i);
			 Grid2-> Rows[i] -> Cells[0]-> Value =aux1;
			 }
		 }
};
}

