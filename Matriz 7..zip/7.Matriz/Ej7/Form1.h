#pragma once
#include "MATRIZ.h"

namespace Ej7 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	MATRIZ M1;
	MATRIZ M2;
	int posf=0;int posc=0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtSuc;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridView^  Grid2;

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtVT;
	private: System::Windows::Forms::TextBox^  txtSucMay;

	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtMesMen;

	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  btnDatos;
	private: System::Windows::Forms::TextBox^  txtDatos;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtSuc2;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn7;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn8;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn9;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn10;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn2;







	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtSuc = (gcnew System::Windows::Forms::TextBox());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtVT = (gcnew System::Windows::Forms::TextBox());
			this->txtSucMay = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtMesMen = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->btnDatos = (gcnew System::Windows::Forms::Button());
			this->txtDatos = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtSuc2 = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->dataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataGridViewTextBoxColumn7 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataGridViewTextBoxColumn8 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataGridViewTextBoxColumn9 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataGridViewTextBoxColumn10 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataGridViewTextBoxColumn2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(43, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(59, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Sucursales";
			// 
			// txtSuc
			// 
			this->txtSuc->Location = System::Drawing::Point(108, 6);
			this->txtSuc->Name = L"txtSuc";
			this->txtSuc->Size = System::Drawing::Size(100, 20);
			this->txtSuc->TabIndex = 1;
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(214, 6);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(75, 23);
			this->btnIngresar->TabIndex = 2;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// Grid
			// 
			this->Grid->BackgroundColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(5) {this->dataGridViewTextBoxColumn1, 
				this->dataGridViewTextBoxColumn7, this->dataGridViewTextBoxColumn8, this->dataGridViewTextBoxColumn9, this->dataGridViewTextBoxColumn10});
			this->Grid->GridColor = System::Drawing::SystemColors::MenuBar;
			this->Grid->Location = System::Drawing::Point(12, 107);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(884, 198);
			this->Grid->TabIndex = 3;
			this->Grid->ColumnCount = 5;
			// 
			// Grid2
			// 
			this->Grid2->BackgroundColor = System::Drawing::SystemColors::Menu;
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->dataGridViewTextBoxColumn2});
			this->Grid2->Location = System::Drawing::Point(915, 107);
			this->Grid2->Name = L"Grid2";
			this->Grid2->Size = System::Drawing::Size(143, 198);
			this->Grid2->TabIndex = 4;
			this->Grid->ColumnCount = 1;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(372, 9);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(74, 13);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Ventas totales";
			// 
			// txtVT
			// 
			this->txtVT->Location = System::Drawing::Point(359, 24);
			this->txtVT->Name = L"txtVT";
			this->txtVT->Size = System::Drawing::Size(100, 20);
			this->txtVT->TabIndex = 6;
			// 
			// txtSucMay
			// 
			this->txtSucMay->Location = System::Drawing::Point(503, 25);
			this->txtSucMay->Name = L"txtSucMay";
			this->txtSucMay->Size = System::Drawing::Size(100, 20);
			this->txtSucMay->TabIndex = 8;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(486, 9);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(130, 13);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Sucursal con mayor venta";
			// 
			// txtMesMen
			// 
			this->txtMesMen->Location = System::Drawing::Point(648, 24);
			this->txtMesMen->Name = L"txtMesMen";
			this->txtMesMen->Size = System::Drawing::Size(100, 20);
			this->txtMesMen->TabIndex = 10;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(645, 9);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(110, 13);
			this->label4->TabIndex = 9;
			this->label4->Text = L"Mes con menor venta";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(912, 88);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(100, 13);
			this->label5->TabIndex = 11;
			this->label5->Text = L"Ventas por sucursal";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(833, 9);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 48);
			this->button1->TabIndex = 12;
			this->button1->Text = L"Obtener Datos.";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// btnDatos
			// 
			this->btnDatos->Location = System::Drawing::Point(214, 41);
			this->btnDatos->Name = L"btnDatos";
			this->btnDatos->Size = System::Drawing::Size(75, 23);
			this->btnDatos->TabIndex = 15;
			this->btnDatos->Text = L"Ingresar";
			this->btnDatos->UseVisualStyleBackColor = true;
			this->btnDatos->Click += gcnew System::EventHandler(this, &Form1::btnDatos_Click);
			// 
			// txtDatos
			// 
			this->txtDatos->Location = System::Drawing::Point(108, 41);
			this->txtDatos->Name = L"txtDatos";
			this->txtDatos->Size = System::Drawing::Size(100, 20);
			this->txtDatos->TabIndex = 14;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(43, 44);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(35, 13);
			this->label6->TabIndex = 13;
			this->label6->Text = L"Datos";
			// 
			// txtSuc2
			// 
			this->txtSuc2->Location = System::Drawing::Point(108, 81);
			this->txtSuc2->Name = L"txtSuc2";
			this->txtSuc2->Size = System::Drawing::Size(100, 20);
			this->txtSuc2->TabIndex = 17;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(43, 84);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(59, 13);
			this->label7->TabIndex = 16;
			this->label7->Text = L"Sucursales";
			// 
			// dataGridViewTextBoxColumn1
			// 
			this->dataGridViewTextBoxColumn1->HeaderText = L"Enero (1)";
			this->dataGridViewTextBoxColumn1->Name = L"dataGridViewTextBoxColumn1";
			// 
			// dataGridViewTextBoxColumn7
			// 
			this->dataGridViewTextBoxColumn7->HeaderText = L"Febrero (2)";
			this->dataGridViewTextBoxColumn7->Name = L"dataGridViewTextBoxColumn7";
			// 
			// dataGridViewTextBoxColumn8
			// 
			this->dataGridViewTextBoxColumn8->HeaderText = L"Marzo(3)";
			this->dataGridViewTextBoxColumn8->Name = L"dataGridViewTextBoxColumn8";
			// 
			// dataGridViewTextBoxColumn9
			// 
			this->dataGridViewTextBoxColumn9->HeaderText = L"Abril (4)";
			this->dataGridViewTextBoxColumn9->Name = L"dataGridViewTextBoxColumn9";
			// 
			// dataGridViewTextBoxColumn10
			// 
			this->dataGridViewTextBoxColumn10->HeaderText = L"Mayo (5)";
			this->dataGridViewTextBoxColumn10->Name = L"dataGridViewTextBoxColumn10";
			// 
			// dataGridViewTextBoxColumn2
			// 
			this->dataGridViewTextBoxColumn2->HeaderText = L"SucMay";
			this->dataGridViewTextBoxColumn2->Name = L"dataGridViewTextBoxColumn2";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1087, 317);
			this->Controls->Add(this->txtSuc2);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->btnDatos);
			this->Controls->Add(this->txtDatos);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->txtMesMen);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtSucMay);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtVT);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->txtSuc);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
				 int S=Convert::ToInt32(txtSuc->Text);
				 M1.Set_Filas(S);
				 Grid->RowCount=M1.Get_Filas();
				 Grid->ColumnCount=5;
			 }
private: System::Void btnDatos_Click(System::Object^  sender, System::EventArgs^  e) {
			 int V=Convert::ToInt32(txtDatos->Text);
			 M1.Set_Matriz(posf,posc,V);
			 Grid->Rows[posf]->Cells[posc]->Value=V;
			 txtSuc2->Text=Convert::ToString(posf+1);
			 if(posc==4)
			 {
				 posc=0;
				 posf++;
			 }
			 else{
				 posc++;
			 }
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int posf1=0;
			 int posc1=0;
			 MATRIZ M2;
			 M2.Set_Filas(M1.Get_Filas());
			 Grid2->RowCount=M2.Get_Filas();
			 int conttot=0;
			 for(int i=0;i<M1.Get_Filas();i++)
			 {
				 int cont=0;
				 for(int j=0;j<5;j++)
				 {
					 conttot=conttot+M1.Get_Matriz(i,j);
					 cont=cont+M1.Get_Matriz(i,j);
				 }
				 M2.Set_Matriz(i,0,cont);
				 Grid2->Rows[i]->Cells[0]->Value=Convert::ToString(cont);
			 }
			 txtVT->Text=Convert::ToString(conttot);
			 int MayVent=M2.Get_Matriz(0,0);
			 int SucMay=0;
			 for (int i=1;i<M2.Get_Filas();i++)
			 {
				 int a=M2.Get_Matriz(i,0);
				 if(a>SucMay)
					 SucMay=i;
			 }
			txtSucMay->Text=Convert::ToString(SucMay+1);
			MATRIZ M3;
			M3.Set_Filas(1);
			for(int i=0;i<5;i++)
			{	int K=0;
				for(int j=0;j<M1.Get_Filas();j++)
				{
					K=K+M1.Get_Matriz(j,i);
				}
				M3.Set_Matriz(0,i,K);
			}
			int MesMen=M3.Get_Matriz(0,0);
			int Mes=0;
			for(int i=1;i<5;i++)
			{
				int a=M3.Get_Matriz(0,i);
				if(a<MesMen)
					Mes=i;
			}
			txtMesMen->Text=Convert::ToString(Mes+1);
		 }
		 
		 
};
}

