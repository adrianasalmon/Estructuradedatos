#pragma once
#include "Mat.h"

namespace My4Matriz {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	Mat M1;
	int posf=0;
	int posc=0;
	Mat M2;
	int posf2=0;
	int posc2=0;
	Mat M3;
	int posf3=0;
	int posc3=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  grilla3;
	protected: 
	private: System::Windows::Forms::Button^  btnResta;
	private: System::Windows::Forms::TextBox^  txtcolumna2;
	private: System::Windows::Forms::TextBox^  txtfila2;
	private: System::Windows::Forms::Button^  btnDefinir2;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::DataGridView^  grilla2;
	private: System::Windows::Forms::TextBox^  txtelemento2;
	private: System::Windows::Forms::Button^  btnIngresar2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::DataGridView^  grilla1;
	private: System::Windows::Forms::TextBox^  txtelemento;
	private: System::Windows::Forms::TextBox^  txtcolumna;
	private: System::Windows::Forms::TextBox^  txtfila;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  f;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->grilla3 = (gcnew System::Windows::Forms::DataGridView());
			this->btnResta = (gcnew System::Windows::Forms::Button());
			this->txtcolumna2 = (gcnew System::Windows::Forms::TextBox());
			this->txtfila2 = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir2 = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->grilla2 = (gcnew System::Windows::Forms::DataGridView());
			this->txtelemento2 = (gcnew System::Windows::Forms::TextBox());
			this->btnIngresar2 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->grilla1 = (gcnew System::Windows::Forms::DataGridView());
			this->txtelemento = (gcnew System::Windows::Forms::TextBox());
			this->txtcolumna = (gcnew System::Windows::Forms::TextBox());
			this->txtfila = (gcnew System::Windows::Forms::TextBox());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->f = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->BeginInit();
			this->SuspendLayout();
			// 
			// grilla3
			// 
			this->grilla3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla3->Location = System::Drawing::Point(400, 453);
			this->grilla3->Name = L"grilla3";
			this->grilla3->RowTemplate->Height = 24;
			this->grilla3->Size = System::Drawing::Size(377, 147);
			this->grilla3->TabIndex = 72;
			// 
			// btnResta
			// 
			this->btnResta->Location = System::Drawing::Point(245, 458);
			this->btnResta->Name = L"btnResta";
			this->btnResta->Size = System::Drawing::Size(116, 29);
			this->btnResta->TabIndex = 71;
			this->btnResta->Text = L"Resta";
			this->btnResta->UseVisualStyleBackColor = true;
			this->btnResta->Click += gcnew System::EventHandler(this, &Form1::btnResta_Click);
			// 
			// txtcolumna2
			// 
			this->txtcolumna2->Location = System::Drawing::Point(680, 143);
			this->txtcolumna2->Name = L"txtcolumna2";
			this->txtcolumna2->Size = System::Drawing::Size(97, 22);
			this->txtcolumna2->TabIndex = 70;
			// 
			// txtfila2
			// 
			this->txtfila2->Location = System::Drawing::Point(680, 99);
			this->txtfila2->Name = L"txtfila2";
			this->txtfila2->Size = System::Drawing::Size(97, 22);
			this->txtfila2->TabIndex = 69;
			// 
			// btnDefinir2
			// 
			this->btnDefinir2->Location = System::Drawing::Point(794, 119);
			this->btnDefinir2->Name = L"btnDefinir2";
			this->btnDefinir2->Size = System::Drawing::Size(116, 29);
			this->btnDefinir2->TabIndex = 68;
			this->btnDefinir2->Text = L"Definir";
			this->btnDefinir2->UseVisualStyleBackColor = true;
			this->btnDefinir2->Click += gcnew System::EventHandler(this, &Form1::btnDefinir2_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(589, 143);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(61, 17);
			this->label4->TabIndex = 67;
			this->label4->Text = L"columna";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(589, 101);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(26, 17);
			this->label5->TabIndex = 66;
			this->label5->Text = L"fila";
			// 
			// grilla2
			// 
			this->grilla2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla2->Location = System::Drawing::Point(548, 251);
			this->grilla2->Name = L"grilla2";
			this->grilla2->RowTemplate->Height = 24;
			this->grilla2->Size = System::Drawing::Size(347, 147);
			this->grilla2->TabIndex = 65;
			// 
			// txtelemento2
			// 
			this->txtelemento2->Location = System::Drawing::Point(680, 200);
			this->txtelemento2->Name = L"txtelemento2";
			this->txtelemento2->Size = System::Drawing::Size(97, 22);
			this->txtelemento2->TabIndex = 64;
			// 
			// btnIngresar2
			// 
			this->btnIngresar2->Location = System::Drawing::Point(815, 197);
			this->btnIngresar2->Name = L"btnIngresar2";
			this->btnIngresar2->Size = System::Drawing::Size(116, 29);
			this->btnIngresar2->TabIndex = 63;
			this->btnIngresar2->Text = L"Ingresar";
			this->btnIngresar2->UseVisualStyleBackColor = true;
			this->btnIngresar2->Click += gcnew System::EventHandler(this, &Form1::btnIngresar2_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(584, 203);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(66, 17);
			this->label1->TabIndex = 62;
			this->label1->Text = L"elemento";
			// 
			// grilla1
			// 
			this->grilla1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla1->Location = System::Drawing::Point(69, 251);
			this->grilla1->Name = L"grilla1";
			this->grilla1->RowTemplate->Height = 24;
			this->grilla1->Size = System::Drawing::Size(347, 147);
			this->grilla1->TabIndex = 61;
			// 
			// txtelemento
			// 
			this->txtelemento->Location = System::Drawing::Point(173, 197);
			this->txtelemento->Name = L"txtelemento";
			this->txtelemento->Size = System::Drawing::Size(97, 22);
			this->txtelemento->TabIndex = 60;
			// 
			// txtcolumna
			// 
			this->txtcolumna->Location = System::Drawing::Point(173, 141);
			this->txtcolumna->Name = L"txtcolumna";
			this->txtcolumna->Size = System::Drawing::Size(97, 22);
			this->txtcolumna->TabIndex = 59;
			// 
			// txtfila
			// 
			this->txtfila->Location = System::Drawing::Point(173, 97);
			this->txtfila->Name = L"txtfila";
			this->txtfila->Size = System::Drawing::Size(97, 22);
			this->txtfila->TabIndex = 58;
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(308, 194);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(116, 29);
			this->btnIngresar->TabIndex = 57;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(287, 117);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(116, 29);
			this->btnDefinir->TabIndex = 56;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(77, 200);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(66, 17);
			this->label3->TabIndex = 55;
			this->label3->Text = L"elemento";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(82, 141);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(61, 17);
			this->label2->TabIndex = 54;
			this->label2->Text = L"columna";
			// 
			// f
			// 
			this->f->AutoSize = true;
			this->f->Location = System::Drawing::Point(82, 99);
			this->f->Name = L"f";
			this->f->Size = System::Drawing::Size(26, 17);
			this->f->TabIndex = 53;
			this->f->Text = L"fila";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1000, 696);
			this->Controls->Add(this->grilla3);
			this->Controls->Add(this->btnResta);
			this->Controls->Add(this->txtcolumna2);
			this->Controls->Add(this->txtfila2);
			this->Controls->Add(this->btnDefinir2);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->grilla2);
			this->Controls->Add(this->txtelemento2);
			this->Controls->Add(this->btnIngresar2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->grilla1);
			this->Controls->Add(this->txtelemento);
			this->Controls->Add(this->txtcolumna);
			this->Controls->Add(this->txtfila);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->f);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
		int fila;int columna;
		 columna=System::Convert::ToInt32(txtcolumna->Text);
		 fila=System::Convert::ToInt32(txtfila->Text);
		 M1.Set_fil(fila);
		 M1.Set_col(columna);
		 grilla1->ColumnCount=columna;
		 grilla1->RowCount=fila; 
			 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
		int ele;
		 ele=System::Convert::ToInt32(txtelemento->Text);
		 M1.Set_Matriz(posf,posc,ele);
		 if(M1.LLena())
		 {

		  MessageBox::Show("Esta llena");
		 }
		 else
		 {
			grilla1->Rows[posf]->Cells[posc]->Value=M1.Get_Matriz(posf,posc);
			if(posc==M1.Get_col()-1)
			{
			posc=0;
			posf++;
			}
			else
			{
			posc++;
			}
		 }
		 }
private: System::Void btnDefinir2_Click(System::Object^  sender, System::EventArgs^  e) {
		int fila;int columna;
		 columna=System::Convert::ToInt32(txtcolumna2->Text);
		 fila=System::Convert::ToInt32(txtfila2->Text);
		 M2.Set_fil(fila);
		 M2.Set_col(columna);
		 grilla2->ColumnCount=columna;
		 grilla2->RowCount=fila;
		 }
private: System::Void btnIngresar2_Click(System::Object^  sender, System::EventArgs^  e) {
		int ele2;
		 ele2=System::Convert::ToInt32(txtelemento2->Text);
		 M2.Set_Matriz(posf2,posc2,ele2);
		 if(M2.LLena())
		 {
		  MessageBox::Show("Esta llena");
		 }
		 else
		 {
			grilla2->Rows[posf2]->Cells[posc2]->Value=M2.Get_Matriz(posf2,posc2);
			if(posc2==M2.Get_col()-1)
			{
			posc2=0;
			posf2++;
			}
			else
			{
			posc2++;
			}
		 }
		 }
private: System::Void btnResta_Click(System::Object^  sender, System::EventArgs^  e) {
			 M3=M3.Resta(M1,M2);
			 grilla3->ColumnCount=M3.Get_col();
		     grilla3->RowCount=M3.Get_fil();
			 while(posf3<M3.Get_fil())
			 {
			 if(M1.Get_fil()==M2.Get_fil()&&M1.Get_col()==M2.Get_col())
			 {
				grilla3->Rows[posf3]->Cells[posc3]->Value=M3.Get_Matriz(posf3,posc3);
				if(posc3==M3.Get_col()-1)
				{
				posc3=0;
				posf3++;
				}
				else
				{
				posc3++;
				}
			 }
			 else
			 {
				 MessageBox::Show("NO SE PUEDE RESTAR VERIFIQUE");
			 }
			 }
		 }
};
}

