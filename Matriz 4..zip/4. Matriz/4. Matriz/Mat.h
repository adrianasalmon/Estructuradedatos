#pragma once
#define a 50
#define b 50
 class Mat
{
private:
	int fil;
	int col;
	int Matriz[a][b];
public:
	Mat(void);
	int Get_fil();
	void Set_fil(int f);
	int Get_col();
	void Set_col(int c);
	int Get_Matriz(int posf, int posc);
	void Set_Matriz(int posf, int posc, int ele);
	bool LLena();
	bool Vacia();
	Mat Resta(Mat M1, Mat M2);
};

