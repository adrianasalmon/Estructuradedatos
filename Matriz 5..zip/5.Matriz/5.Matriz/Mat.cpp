#include "StdAfx.h"
#include "Mat.h"

Mat::Mat(void)
{ col=0;
 fil=0;
 Matriz[a][b]=0;
}
int Mat::Get_fil()
{ return fil;
}
void Mat::Set_fil(int f)
    { fil=f;
	}
int Mat::Get_col()
	{ return col;
	}
void Mat::Set_col(int c)
	{ col=c;
	}
int Mat::Get_Matriz(int posf, int posc)
	{ return Matriz[posf][posc];
	}
void Mat::Set_Matriz(int posf, int posc, int ele)
	{ Matriz[posf][posc]=ele;
	}

bool Mat::LLena()
{
	if (fil==a-1 && col==b-1)
	{
		return true;
	}
	else
	{
		return false;
	}

}
bool Mat::Vacia()
{
	if(fil==0 && col==0)
		{
	return true;
}
else
	{
		return false;
	}

}

Mat Mat::Multiplicacion(Mat M1, Mat M2)
{
	Mat M3;
	M3.Set_fil(M1.Get_fil());
	M3.Set_col(M2.Get_col());
	for(int kf=0;kf<M1.Get_fil();kf++)
	{
		for(int kg=0;kg<M2.Get_col();kg++)
		{int n;
		 for(int kc=0;kc<M1.Get_col();kc++)
			{
				n=n+M1.Get_Matriz(kf,kc)*M2.Get_Matriz(kc,kg);
			}
		 	M3.Set_Matriz(kf,kg,n);
		}

    }
return M3;
}