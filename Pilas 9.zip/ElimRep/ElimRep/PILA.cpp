#include "StdAfx.h"
#include "PILA.h"


PILA::PILA(void)
{
	tope =-1;
	P[N]=0;
}
int PILA::Get_Tope(){
	return tope;
}
void PILA::Apilar(int elem){
	P[++tope]=elem;
}
int PILA::Desapilar(){
	int fin=P[tope--];
	return fin;
}
bool PILA::Lleno(){
	if(tope==N-1)
		return true;
}
bool PILA::Vacio(){
	if(tope==-1)
		return true;
}
