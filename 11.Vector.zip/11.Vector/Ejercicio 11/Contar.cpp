#include "StdAfx.h"
#include "Contar.h"
#define M 100;

Contar::Contar(void)
{
}
int Contar::Get_tamano()
{return tamano;}

void Contar::Set_tamano(int tam)
{tamano=tam;}

double Contar::Get_vector(int posicion)
{return vec[posicion];}

void Contar::Set_vector(int posicion, double elemento)
{vec[posicion]=elemento;}

bool Contar::LlenoVector()
{
	if(tamano==99)
{return true;}else{return false;}
}

bool Contar::VacioVector()
{if(tamano==0)
{return true;}else{return false;}
}

bool Contar::Llenar(int pos, double elemento)
{if((pos<0)&&(pos>tamano)){return false;}
else{
	if(LlenoVector()==true){return false;}
	else{
		int i=Get_tamano();
		while(i>pos)
		{vec[i]=vec[i-1];i--;}
		vec[i]=elemento;
		return true;
		}
	}
}
int Contar::ContarPosi(int tam)
{int Pos=0;
	for(int i=0;i<tam;i++)
		{if(vec[i]>0)
		Pos=Pos+1;
		}
	return Pos;
}

int Contar::ContarNeg(int tam)
{int Neg=0;
	for(int i=0;i<tam;i++)
		{if(vec[i]<0)
		Neg=Neg+1;
		}
	return Neg;
}
int Contar::ContarCero(int tam)
{int Cero=0;
	for(int i=0;i<tam;i++)
		{if(vec[i]==0)
		Cero=Cero+1;
		}
	return Cero;
}

