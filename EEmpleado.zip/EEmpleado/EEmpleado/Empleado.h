#pragma once
#include <iostream>
#include <string>
using namespace std;

class Empleado
{
private:
	string nombre;
	double ID;
	double haberbasico;
	int antiguedad;
	double totalganado;
	double descuentos;
public:
	Empleado(void);
	string Get_Nombre();
	double Get_ID();
	double Get_Haberbasico();
	int Get_Antiguedad();
	void Set_Nombre(string nom);
	void Set_ID (double id);
	void Set_Haberbasico(double hb);
	void Set_Antiguedad(int ant);
	double calculartotalganado();
	double calculardescuentosAFP();

};

