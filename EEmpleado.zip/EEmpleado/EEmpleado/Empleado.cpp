#include "StdAfx.h"
#include "Empleado.h"

Empleado::Empleado(void)
{

}

string Empleado::Get_Nombre()
{
	return nombre;
}
double Empleado::Get_ID()
{
	return ID;
}
double Empleado::Get_Haberbasico()
{
	return haberbasico;
}
int Empleado::Get_Antiguedad()
{
	return antiguedad;
}
void Empleado::Set_Nombre(string nom)
{
	nombre=nom;
}
void Empleado::Set_ID (double id)
{
	ID=id;
}
void Empleado::Set_Haberbasico(double hb)
{
	haberbasico=hb;
}
void Empleado::Set_Antiguedad(int ant)
{
	antiguedad=ant;
}
double Empleado::calculartotalganado()
{
	if(antiguedad<=4)
	{
		totalganado=haberbasico+(3*2122*0.05);
	}
	else
	{
		totalganado=haberbasico+(3*2122*0.07);
	}
	return totalganado;
}
double Empleado::calculardescuentosAFP()
{
	descuentos=haberbasico*0.1271;
	return descuentos;
}

